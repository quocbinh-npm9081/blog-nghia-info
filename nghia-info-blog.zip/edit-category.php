<?php
include 'admin/partials/header.php'
?>
    <section class="form__section">
        <div class="container form__section-container">
            <h2>CHỈNH SỬA THỂ LOẠI</h2>
            <div class="alert__message error">
                <p>This is an error</p>
            </div>
            <form action="" method="post" class="form">
                <input type="text" placeholder="Tiêu đề">
                <textarea name="" id="" cols="30" rows="10" placeholder="Mô tả"></textarea>

                <button type="submit" class="btn">Cập nhập</button>
            </form>
        </div>

    </section>

</body>

</html>