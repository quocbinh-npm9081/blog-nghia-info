<?php
session_start();
    // define('ROOT_URL','http://localhost/nghia-info-blog');
    // define('DB_HOST', 'localhost');
    // define('DB_USER', 'root');
    // define('DB_PASSWORD', '');
    // define('DB_NAME', 'nghia-info');  
    define('ROOT_URL','sql208.epizy.com');
    define('DB_HOST', 'sql208.epizy.com');
    define('DB_USER', 'epiz_33137997');
    define('DB_PASSWORD', 'Oetra4Nywxy');
    define('DB_NAME', 'epiz_33137997_nghiaInfo');  
    define('DB_PORT', 3306);  
?>